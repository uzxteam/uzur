<?php 

# Determines how often Google ads appear in feeds (Only integer values are allowed) 
define("GADS_TIMELINE_FREQ", 5);
