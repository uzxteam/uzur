<?php 

require_once(cl_full_path('core/libs/PHPMailer/PHPMailerAutoload.php'));
$mail = new PHPMailer(true);
