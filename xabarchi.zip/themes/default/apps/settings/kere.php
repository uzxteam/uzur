<div class="nav-list-itemset-title">
				<h4><?php echo cl_translate("My account information"); ?></h4>
			</div>
			<div class="nav-list-item" onclick="CLSettings.open('account-info');">
				<div class="lp">
					<span class="preview-label"><?php echo cl_translate("Download my information"); ?></span>
					<span class="preview-value">
						<?php echo cl_translate("Please choose what information you want to download"); ?> 
					</span>
				</div>
				<div class="rp">
					<?php echo cl_ikon("download"); ?>
				</div>
			</div>
			<div class="nav-list-itemset-title">
				<h4><?php echo cl_translate("Delete profile"); ?></h4>
			</div>
			<div class="nav-list-item nav-list-item-delete" onclick="CLSettings.open('delete-settings');">
				<div class="lp">
					<span class="preview-label"><?php echo cl_translate("Delete profile"); ?></span>
					<span class="preview-value">
						<?php echo cl_translate("Click to confirm deletion of your profile"); ?> 
					</span>
				</div>
				<div class="rp">
					<?php echo cl_ikon("bin"); ?>
				</div>
			</div>